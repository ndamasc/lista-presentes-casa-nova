# Análise técnica – Chá de Panela Bridgerton (`cha_panela_bridgerton_v3.html`)

> Arquivo analisado sem qualquer alteração (702 linhas, \~17,7 KB, HTML + CSS + JS em um único arquivo). Números de linha referem-se ao arquivo original.

---

## 1\. Resumo executivo

| Tema | Veredito |
| --- | --- |
| Backend | **Não existe.** É 100% estático/client-side. |
| Banco de dados | **Não é necessário** para o cenário descrito (quantidade livre, lista e valores fechados). |
| Maior problema | **O "QR Code Pix" não é um Pix válido** (L.628-632): é um texto solto. O banco do convidado não vai reconhecê-lo. |
| Segundo maior | **Chave Pix parece ser um CPF (11 dígitos) exposto em texto puro** (L.581) e enviado a um serviço de terceiros ([qrserver.com](http://qrserver.com)). |
| Terceiro | O item vira "Escolhido ✓" ao simplesmente **fechar o modal**, sem pagamento confirmado, e **o estado se perde ao recarregar**. |
| Imagens | Nenhum presente tem imagem real; todos usam o mesmo emoji 🫖. A imagem do hero (`w1-removebg-preview.png`) é relativa e pode quebrar. |
| Acessibilidade | Modal sem `role="dialog"`, sem ESC, sem foco preso, sem scroll lock; botão fechar é um `<span>`. |
| Esforço de correção | Pequeno: tudo se resolve no próprio front-end, sem servidor. |

---

## 2\. Arquitetura atual e como o "backend" funciona

### 2.1 Estrutura

* **Hero** (L.531-556): imagem, título, texto de anúncio, botão âncora.

* **Grade de presentes** `#gifts` (L.560), preenchida por JS.

* **Modal Pix** `#pixModal` (L.563-580).

* **Script** (L.585-699): array `presentes`, renderização, modal, cópia, animação de flores.

### 2.2 Fluxo real

1. `presentes` (L.587-598) é um array de pares `[nome, "R$ valor"]` – **21 itens, total R$ 4.125** se todos fossem comprados uma vez.

2. `forEach` cria um `div.card` com `innerHTML` (L.612) e liga `onclick` ao botão (L.619).

3. Ao clicar, monta a string `Chave: … | Item: … | Valor: …` e chama `api.qrserver.com` para gerar a imagem (L.628-632).

4. Ao fechar o modal (L.641), o card é marcado como reservado **só na memória do navegador**.

5. "Copiar Chave Pix" (L.652) copia apenas a chave, sem valor.

### 2.3 Conclusão sobre o "backend"

* **Não há servidor, API própria, banco, nem persistência** (nenhum `fetch`, `localStorage`, formulário).

* Isso significa: o "Escolhido ✓" é **apenas visual e local**. Outro convidado (ou o mesmo, após F5) vê tudo disponível. Não existe "reserva" de verdade.

* **O dinheiro vai direto para a conta do casal via Pix** – o site não sabe se alguém pagou. O casal só descobre pelo extrato do banco, sem saber _qual item_ foi (o payload atual nem chega ao banco).

---

## 3\. Banco de dados é necessário?

**Não.** Um banco serve para controle de estoque/unicidade (evitar dois convidados darem o mesmo item). O cliente declarou que:

* aceita receber vários presentes iguais → não há necessidade de exclusividade;

* presentes e valores já estão fechados → dados são estáticos.

Portanto:

* A lista deve ser um **JSON/array estático** (versionado junto do site).

* O "Escolhido ✓" deveria ser removido, ou virar apenas uma **confirmação opcional** ("já presenteei") guardada em `localStorage` do próprio visitante, só para conforto dele.

* Único dado dinâmico útil: **saber quem presenteou o quê** (para agradecimento). Isso se resolve com um formulário/planilha (ver §4), não com banco.

### 3.1 Quando um banco passaria a ser justificável

Somente se o cliente mudar de ideia: itens com quantidade limitada, bloqueio em tempo real entre convidados, painel administrativo, ou conciliação automática de pagamentos. Mesmo assim, Firebase/Supabase (plano gratuito) seria suficiente – nunca um servidor próprio.

---

## 4\. Alternativas leves

| Opção | Como funcionaria | Prós | Contras | Custo |
| --- | --- | --- | --- | --- |
| **A. Manter 100% estático + Pix BR Code válido (recomendado)** | Gera payload Pix EMV no navegador (código no §11), QR local, copia-e-cola com valor | Zero infraestrutura, zero dependência externa, funciona offline, chave não vai para terceiros | Sem registro de quem pagou (só extrato) | Grátis |
| **B. A + "Avisar o casal" via Formspree/Google Forms** | Após pagar, convidado preenche nome + item (campo opcional) | Casal sabe quem deu o quê; simples | Depende de boa-fé; spam possível (usar honeypot) | Grátis (Formspree: limite mensal baixo no plano free) |
| **C. A + Google Sheets via Apps Script (Web App)** | `fetch` POST para um Apps Script que escreve numa planilha | Planilha em tempo real para o casal, contador por item possível | CORS exige `mode:'no-cors'` ou tratamento; URL do script fica pública; cota do Google | Grátis |
| **D. JSON estático + função serverless (Netlify/Cloudflare/Vercel)** | `gifts.json` + endpoint para registrar | Controle total, pode validar e limitar abuso | Mais peças para manter; excessivo para o caso | Grátis (planos free) |
| **E. Link de pagamento (Mercado Pago, PagSeguro, Pix cobrança do banco)** | Um link por presente | Confirmação automática de pagamento, recibo | Taxas (cartão), cadastro, 21 links para manter; Pix costuma ter taxa baixa/zero conforme provedor | Variável |
| **F. Firebase/Supabase** | Banco gerenciado | Tempo real, reserva real | Excesso para o caso; exige regras de segurança | Grátis até certo volume |

**Recomendação:** **A + B** (ou A + C se o casal quiser planilha). É o menor conjunto que resolve o problema real (Pix válido e saber quem presenteou) sem servidor.

---

## 5\. Segurança

### 5.1 Pix e dados sensíveis (CRÍTICO)

1. **Chave exposta (L.581):** `<input type="hidden" value="00636779203">`. `hidden` não esconde nada: aparece no código-fonte. Pelo formato (11 dígitos) parece **CPF** – dado pessoal (LGPD) que serve para golpistas/engenharia social. _Hipótese: confirmar com o cliente._ Mitigações: usar chave aleatória (EVP) ou e-mail/telefone dedicado ao evento; ou o cliente aceitar o risco conscientemente. Em Pix o nome do recebedor é exibido pelo banco ao pagar, então a chave nunca ficará totalmente "privada".

2. **Vazamento para terceiro (L.628-632):** a chave + item + valor são enviados na URL a `api.qrserver.com` (logs de terceiros, queda do serviço = QR some). Gerar o QR localmente (biblioteca de \~4 KB ou pré-gerar PNGs) elimina isso.

3. **QR inválido:** `Chave: … | Item: … | Valor: …` não é BR Code EMV (padrão BCB). O banco mostrará "QR inválido". **Isso é um defeito funcional crítico**: o convidado só consegue pagar copiando a chave manualmente e digitando o valor.

4. **Sem valor no copia-e-cola:** o botão copia só a chave; o convidado digita o valor de cabeça.

5. **Risco de adulteração:** como é site estático hospedado, o risco é de a hospedagem/arquivo ser alterado. Use HTTPS, 2FA na conta de hospedagem e conferência do nome do recebedor.

### 5.2 XSS

* `card.innerHTML` com `${nome}` e `${valor}` (L.612-617): **hoje é seguro** porque os dados são constantes do próprio código. Mas é um padrão frágil: se a lista passar a vir de JSON externo/planilha/formulário, vira XSS. Corrigir com `textContent`/`createElement` (exemplo §11).

* `f.innerHTML` das flores (L.673): conteúdo constante, sem risco; usar `textContent` por consistência.

* `modalGiftName.innerText` (L.621): seguro.

* Não há `eval`, `document.write`, nem parâmetros de URL lidos.

### 5.3 Validação

* `valor.replace("R$ ", "").replace(",", ".")` (L.626) é frágil: com `"R$ 1.000"` viraria `1.000` (= 1 real!). Hoje nenhum valor passa de 490, mas qualquer edição futura quebra silenciosamente. **Guarde o valor como número** (`490`) e formate só para exibir.

* Se for adicionado formulário (opção B/C): validar tamanho, usar honeypot, `maxlength`, e nunca confiar no cliente.

### 5.4 Cabeçalhos e dependências

* Sem CSP. Sugestão (via meta ou headers da hospedagem): `default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src https://fonts.gstatic.com`.

* Dependências externas: Google Fonts e qrserver (esta última deve sair).

* `window.onclick` (L.661) e `onclick =` sobrescrevem handlers: use `addEventListener`.

---

## 6\. Janelas/modais (acessibilidade, foco, ESC, scroll lock, responsividade)

| \# | Problema | Local | Impacto |
| --- | --- | --- | --- |
| 1 | Sem `role="dialog"`, `aria-modal="true"`, `aria-labelledby` | L.563 | Leitor de tela não anuncia o modal |
| 2 | Botão fechar é `<span>×</span>` sem `tabindex`/`aria-label` | L.564 | Inacessível por teclado e leitores |
| 3 | **Sem fechar com ESC** | L.641-665 | Falha WCAG 2.1.2/UX |
| 4 | **Sem foco preso (focus trap)** nem foco inicial no modal | – | Tab navega para a página atrás |
| 5 | **Foco não retorna** ao botão "Presentear" ao fechar | L.641 | Usuário de teclado se perde |
| 6 | **Sem scroll lock**: o fundo rola atrás | L.651/`display:flex` | Ruim no mobile |
| 7 | Modal `position:fixed` sem `overflow-y:auto` / `max-height` | CSS L.357-368 | Em celular baixo/paisagem, o botão "Copiar" pode ficar inacessível |
| 8 | Fechar (qualquer forma) **marca como "Escolhido ✓"** | L.641-648 | Clique acidental ou curiosidade "reserva" o item; semântica errada |
| 9 | Clique fora e × usam o mesmo handler | L.661-665 | Mesmo problema do item 8 |
| 10 | `animation` sem `prefers-reduced-motion` | CSS L.381 | Acessibilidade vestibular |
| 11 | Feedback de cópia sem `aria-live`; falha do `clipboard` sem tratamento | L.652-657 | Em HTTP/iframe/Safari antigo `navigator.clipboard` é indefinido → erro |
| 12 | Alvo do ×: \~24 px | CSS L.389 | Abaixo de 44 px recomendado no toque |

**Responsividade:** o `@media (max-width:768px)` (L.469-527) é razoável (botões 48 px, QR 150 px, modal 95%). Faltam: `100dvh`/scroll interno no modal e breakpoints intermediários para a grade.

Alternativa moderna: usar `<dialog>` + `showModal()` – entrega ESC, foco preso, `aria-modal` e backdrop gratuitamente (exemplo §11).

---

## 7\. Imagens reais de cada presente

### 7.1 Situação atual

Todos os 21 cards usam o mesmo `<div class="card-icon">🫖</div>` (L.613). Resultado: sem identidade visual, sem informação, sem `alt`, e um bule de chá para itens como "Edredom" e "Air Fryer".

### 7.2 Lista de itens e problemas

| \# | Presente | Valor | Problema atual | Sugestão de imagem real |
| --- | --- | --- | --- | --- |
| 1 | Jogo de Panelas de cerâmica | R$ 490 | 🫖 genérico | Foto de conjunto de panelas cerâmicas (cor creme/lavanda combina com o tema) |
| 2 | Formas e Assadeiras | R$ 250 | idem | Conjunto de formas retangulares/redondas |
| 3 | Frigideira Antiaderente | R$ 120 | idem | Frigideira 24-28 cm |
| 4 | Faqueiro | R$ 180 | idem | Faqueiro 24-30 peças (dourado combina) |
| 5 | Conjunto de Pratos | R$ 220 | idem | Aparelho de jantar |
| 6 | Conjunto de Copos | R$ 80 | idem | Copos de vidro |
| 7 | Conjunto de Taças | R$ 110 | idem | Taças de vinho/água |
| 8 | Conjunto de Xícaras | R$ 170 | idem (🫖 ao menos é coerente) | Xícaras com pires |
| 9 | Jogo de Banho | R$ 180 | idem | Toalhas de banho dobradas |
| 10 | Kit de Toalhas | R$ 230 | idem; **quase duplicado de #9** | Toalhas de rosto/mesa (diferenciar na descrição) |
| 11 | Edredom Casal | R$ 480 | idem | Cama com edredom |
| 12 | Liquidificador | R$ 220 | idem | Liquidificador |
| 13 | Air Fryer | R$ 450 | idem | Air fryer |
| 14 | Cafeteira | R$ 300 | idem | Cafeteira elétrica |
| 15 | Sanduicheira | R$ 150 | idem | Sanduicheira |
| 16 | Almofadas | R$ 100 | idem | Almofadas decorativas |
| 17 | Utensílios de Cozinha | R$ 100 | idem | Kit de espátulas/colheres |
| 18 | Tábua de Corte | R$ 50 | idem | Tábua de madeira |
| 19 | Escorredor de Louça | R$ 90 | idem | Escorredor |
| 20 | Potes Organizadores | R$ 80 | idem | Potes herméticos |
| 21 | Kit de Temperos | R$ 75 | idem | Porta-temperos/potinhos |

### 7.3 Fontes de imagem

* **Bancos livres (licença permitindo uso comercial/sem atribuição):** Unsplash, Pexels, Pixabay – boas para ambientação (cozinha, mesa posta), mas nem sempre para o produto exato.

* **Fotos do produto real:** das lojas onde o casal quer sugerir (Amazon, Magalu, Mercado Livre, Tramontina). **Atenção a direitos:** hotlinkar imagens de loja é frágil (URLs mudam) e pode violar termos; o ideal é **baixar com autorização/ou usar fotos próprias** e hospedar localmente.

* **Ilustrações consistentes** (alternativa mais barata e coesa com o tema): conjunto de ícones/ilustrações em aquarela estilo Regency, gerado por IA ou comprado (Freepik/Creative Market, conferir licença).

* Recomendação: **imagens próprias hospedadas junto do site**, proporção única (4:3 ou 1:1), fundo creme.

### 7.4 Otimização e boas práticas

* Formato **WebP/AVIF** com fallback JPG; largura máx. \~480 px (2x para retina ≈ 800 px); alvo < 40 KB cada (21 imagens < \~900 KB total).

* `loading="lazy"` e `decoding="async"` em todas as imagens da grade; `width`/`height` explícitos (evita CLS); `aspect-ratio` no CSS.

* `alt` descritivo ("Jogo de panelas de cerâmica cor creme"), não "imagem".

* **Fallback:** `onerror` troca por emoji/placeholder SVG.

* Usar `srcset`/`sizes` ou `<picture>`.

Exemplo no §11 (dados + card com imagem + fallback).

---

## 8\. Performance, SEO, mobile e manutenção

### 8.1 Performance

* **Animação de flores:** `setInterval(createFlower, 900)` (L.698) roda para sempre e cria nós DOM com `setTimeout` de remoção; continua rodando em aba oculta (acumula timers). Melhor: limitar quantidade, pausar em `document.hidden`, respeitar `prefers-reduced-motion`, usar `will-change: transform` / animar `transform` em vez de `top` (verificar CSS `@keyframes`).

* **4 famílias de fonte / 9 pesos** do Google Fonts (L.11): reduzir pesos, usar `font-display: swap` (já há `display=swap`), considerar self-host.

* **Dependência externa do QR** (latência + ponto único de falha).

* CSS/JS inline: ok para arquivo único (menos requisições), mas sem cache separado. Aceitável para este tamanho.

* **Imagem do hero** `w1-removebg-preview.png` (L.535): PNG com fundo removido tende a ser pesado; converter para WebP, definir `width/height`.

### 8.2 SEO / compartilhamento (relevante: link será enviado por WhatsApp)

Ausentes: `meta description`, **Open Graph/Twitter Card** (`og:title`, `og:description`, `og:image`) – sem eles a prévia no WhatsApp fica pobre; `theme-color`; favicon; `<main>`/`<header>`. Considerar `noindex` se o casal não quer o site público em buscadores (provável, por conter chave Pix e nomes).\
O `<h1>` não existe (o título é `div.journal-title`); há `h2` e `h3` apenas. Estrutura semântica fraca.

### 8.3 Mobile

* Botões de 48 px, bom. Mas cards de `<div>` com botão e emoji: sem imagem a grade parece vazia.

* Uso de `100vw` / `vw` nas flores com `overflow-x:hidden` no body (L.43) pode mascarar overflow; testar em iOS Safari.

* `backdrop-filter` precisa de prefixo `-webkit-` em Safari antigo.

* Considerar botão "Abrir app do banco" não é possível via web de forma universal; o copia-e-cola é o caminho confiável.

### 8.4 Manutenção do código

* **Dados misturados à lógica:** mover `presentes` para `gifts.json` (ou `<script type="application/json">`) com `id, nome, valor(número), imagem, alt, descrição`.

* **Valores como string** `"R$ 490"` → número.

* **Constantes mágicas** espalhadas: chave Pix, tamanhos de QR (180 e CSS 150), 13000 ms, 900 ms, 18 flores, 0.4 s → `const CONFIG = {…}`.

* **Duplicação:** a chave é lida duas vezes do DOM (L.623 e L.653); o texto do botão "Copiar Chave Pix" aparece duas vezes; comentário com instrução "altere o e-mail" contradiz o valor atual (que parece CPF) – L.622 e L.580 pedem "e-mail" / "chave real". `.card:hover`/`.reserve` repetem estilos.

* **Comentários desatualizados/enganosos:** "Mantido o nome original w1.jpg" (L.534) mas o arquivo é `w1-removebg-preview.png`; "API pública e segura do QR Server" (L.567); "simulado" (L.586) – sugerem que o Pix é um protótipo que **nunca foi finalizado**.

* **Bloco comentado** `date-badge` (L.545-549): remover ou ativar.

* **Texto do hero com tom** "a fortuna de um Ducado não lhes foi concedida": é decisão editorial do cliente; apenas recomendo revisar com ele o tom (pedir dinheiro explicitamente) – não é um erro técnico.

* Nomear classes/IDs consistentemente (mistura de português/inglês: `reserve`, `reserved`, `pixModal`).

---

## 9\. Bugs encontrados

| \# | Gravidade | Local | Descrição | Correção |
| --- | --- | --- | --- | --- |
| B1 | **Crítica** | L.628-632 | QR não é BR Code Pix; banco rejeita | Gerar payload EMV com CRC16 (§11) |
| B2 | **Crítica** | L.581 | Chave (parece CPF) em texto no HTML + enviada ao [qrserver.com](http://qrserver.com) | Chave dedicada; QR local |
| B3 | Alta | L.641-648 | Fechar o modal marca item como "Escolhido ✓" mesmo sem pagar | Botão explícito "Já paguei" ou remover estado |
| B4 | Alta | L.641-648 | Estado não persiste; F5 apaga tudo | `localStorage` (apenas visual) ou remover |
| B5 | Alta | L.652-657 | Copia só a chave, não o copia-e-cola com valor; sem `catch` nem fallback | Copiar payload Pix; fallback `execCommand`/seleção |
| B6 | Média | L.626 | `replace(",", ".")` frágil para milhares (`R$ 1.000` → 1.000) | Valores numéricos |
| B7 | Média | L.619/641/661 | `onclick =` / `window.onclick` sobrescrevem handlers; `closeModal.onclick()` chamado manualmente | `addEventListener` + função `fecharModal()` |
| B8 | Média | L.661-665 | `event.target == pixModal` ok, mas fecha e **reserva** pelo fundo | Separar fechar de confirmar |
| B9 | Média | L.563-565 | Sem ESC, foco, ARIA (ver §6) | `<dialog>` |
| B10 | Média | L.535 | Imagem `w1-removebg-preview.png` relativa; se não for enviada junto, imagem quebrada sem fallback | Embutir/hospedar e testar; `onerror` |
| B11 | Média | L.698 | `setInterval` das flores nunca é cancelado, roda em aba oculta | Pausar com `visibilitychange` |
| B12 | Baixa | L.613 | Mesmo emoji para todos; `.card-icon` sem `aria-hidden` | Imagens reais / `aria-hidden="true"` |
| B13 | Baixa | L.612 | `<div>` como card, sem `<article>`/lista semântica | `<ul>/<li>` |
| B14 | Baixa | L.9 e meta | Sem meta description/OG/favicon | §8.2 |
| B15 | Baixa | #9 e #10 | "Jogo de Banho" e "Kit de Toalhas" são quase o mesmo item | Diferenciar descrições ou unir |
| B16 | Baixa | L.534/567/586/622 | Comentários desatualizados | Limpar |

---

## 10\. Melhorias priorizadas

### 🔴 Alta prioridade

1. **Gerar Pix BR Code válido** com valor por presente, localmente (§11-A). Resolve B1, B5.

2. **Remover dependência do [qrserver.com](http://qrserver.com)** (gerar QR local ou pré-gerar PNGs).

3. **Revisar a chave Pix**: usar chave aleatória/e-mail dedicado; retirar o `input hidden`; mover para constante de configuração.

4. **Corrigir a semântica de "Escolhido"**: fechar ≠ reservar. Botão "Já fiz o Pix ✓" (opcional) ou remover; persistir em `localStorage`.

5. **Imagens reais** com lazy loading, `alt`, fallback (§11-C).

### 🟡 Média prioridade

1. Modal acessível via `<dialog>` (ESC, foco, scroll lock, `aria-label`) (§11-B).

2. Separar dados em `gifts.json`/objeto com valores numéricos e `id`.

3. Criar `CONFIG` com constantes; remover duplicações e comentários obsoletos.

4. Substituir `innerHTML` por `createElement/textContent` (§11-C).

5. Registro opcional de "quem presenteou" via Formspree/Google Sheets (§11-D).

6. Meta description, Open Graph, favicon, `theme-color`; decidir `noindex`.

7. Pausar/limitar flores; `prefers-reduced-motion`.

### 🟢 Baixa prioridade

1. Estrutura semântica (`<header>`, `<main>`, `<h1>`, `<ul>`).

2. Self-host de fontes e reduzir pesos.

3. Converter hero para WebP; `width/height`.

4. Prefixos `-webkit-backdrop-filter`; teste em iOS Safari.

5. Remover bloco comentado `date-badge` ou ativar.

6. Filtro/ordenação (por preço) e barra de progresso/contador opcionais.

---

## 11\. Exemplos de código

### A) Pix BR Code válido (EMV + CRC16) – testado

Exemplo gerado (chave fictícia, R$ 490,00):\
`00020126390014br.gov.bcb.pix0117chave@exemplo.com5204000053039865406490.005802BR5918NATHALIA E RAPHAEL6009SAO PAULO62110507PANELAS6304BD2F`

```js
const CONFIG = {
  pixKey: "chave-aleatoria-ou-email@exemplo.com", // não usar CPF se possível
  recebedor: "NATHALIA E RAPHAEL",                // máx. 25 caracteres, sem acento
  cidade: "SAO PAULO",                            // máx. 15 caracteres, sem acento
};

const tlv = (id, v) => id + String(v.length).padStart(2, "0") + v;

function crc16(str) {
  let crc = 0xFFFF;
  for (const ch of new TextEncoder().encode(str)) {
    crc ^= ch << 8;
    for (let i = 0; i < 8; i++)
      crc = (crc & 0x8000) ? ((crc << 1) ^ 0x1021) & 0xFFFF : (crc << 1) & 0xFFFF;
  }
  return crc.toString(16).toUpperCase().padStart(4, "0");
}

function gerarPix({ chave, valor, nome, cidade, txid = "PANELAS" }) {
  const p =
    tlv("00", "01") +
    tlv("26", tlv("00", "br.gov.bcb.pix") + tlv("01", chave)) +
    tlv("52", "0000") + tlv("53", "986") +
    tlv("54", valor.toFixed(2)) +
    tlv("58", "BR") + tlv("59", nome) + tlv("60", cidade) +
    tlv("62", tlv("05", txid)) + "6304";
  return p + crc16(p);
}
```

QR local: incluir uma biblioteca pequena e hospedá-la junto do site (ex.: `qrcode-generator`, \~15 KB) e desenhar em `<canvas>`/SVG; ou pré-gerar 21 PNGs offline. Validar o resultado pagando R$ 0,01 de teste em um banco real antes de publicar.

### B) Modal acessível com `<dialog>`

```html
<dialog id="pixModal" aria-labelledby="modalTitulo">
  <form method="dialog"><button class="close-modal" aria-label="Fechar">×</button></form>
  <h2 id="modalTitulo">Sua Generosidade Encantou a Corte</h2>
  <p id="modalGiftName"></p>
  <canvas id="qr" width="180" height="180" role="img" aria-label="QR Code Pix"></canvas>
  <button id="btnCopyPix" class="btn-copy">Copiar Pix Copia e Cola</button>
  <p id="copyStatus" role="status" aria-live="polite"></p>
</dialog>
```

```js
let botaoOrigem;
function abrirModal(presente, origem) {
  botaoOrigem = origem;
  document.getElementById("modalGiftName").textContent =
    `${presente.nome} (${BRL.format(presente.valor)})`;
  pixAtual = gerarPix({ chave: CONFIG.pixKey, valor: presente.valor,
                        nome: CONFIG.recebedor, cidade: CONFIG.cidade });
  pixModal.showModal();                      // ESC + foco preso + aria-modal nativos
  document.body.style.overflow = "hidden";   // scroll lock
}
pixModal.addEventListener("close", () => {
  document.body.style.overflow = "";
  botaoOrigem?.focus();                      // devolve o foco
});
pixModal.addEventListener("click", e => { if (e.target === pixModal) pixModal.close(); });

btnCopyPix.addEventListener("click", async () => {
  try {
    await navigator.clipboard.writeText(pixAtual);
    copyStatus.textContent = "Código copiado!";
  } catch { copyStatus.textContent = "Não foi possível copiar. Selecione e copie manualmente."; }
});
```

```css
dialog { max-height: 90dvh; overflow-y: auto; }
dialog::backdrop { background: rgba(44,37,48,.6); backdrop-filter: blur(4px); }
@media (prefers-reduced-motion: reduce) { * { animation: none !important; transition: none !important; } }
```

### C) Dados separados + cards seguros com imagem real, lazy e fallback

```js
const BRL = new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL", maximumFractionDigits: 0 });

const presentes = [
  { id: "panelas", nome: "Jogo de Panelas de cerâmica", valor: 490,
    img: "img/panelas.webp", alt: "Jogo de panelas de cerâmica cor creme" },
  { id: "airfryer", nome: "Air Fryer", valor: 450,
    img: "img/airfryer.webp", alt: "Air fryer preta de 4 litros" },
  // ...
];

function criarCard(p) {
  const li = document.createElement("li");
  li.className = "card";

  const img = new Image();
  img.src = p.img; img.alt = p.alt;
  img.loading = "lazy"; img.decoding = "async";
  img.width = 480; img.height = 360;
  img.onerror = () => { img.replaceWith(Object.assign(document.createElement("div"),
                    { className: "card-icon", textContent: "🎁", ariaHidden: "true" })); };

  const h3 = document.createElement("h3");  h3.textContent = p.nome;
  const preco = document.createElement("div"); preco.className = "price"; preco.textContent = BRL.format(p.valor);
  const btn = document.createElement("button"); btn.className = "reserve"; btn.type = "button";
  btn.textContent = "Presentear";
  btn.setAttribute("aria-label", `Presentear com ${p.nome}, ${BRL.format(p.valor)}`);
  btn.addEventListener("click", () => abrirModal(p, btn));

  li.append(img, h3, preco, btn);
  return li;
}
document.getElementById("gifts").append(...presentes.map(criarCard));
```

```css
.card img { width: 100%; aspect-ratio: 4/3; object-fit: cover; border-radius: 4px; background: var(--creme); }
```

### D) Aviso ao casal (Formspree, opcional)

```html
<form id="avisoForm" action="https://formspree.io/f/SEU_ID" method="POST">
  <input name="nome" required maxlength="80" autocomplete="name" placeholder="Seu nome">
  <input name="presente" type="hidden">
  <input name="_gotcha" tabindex="-1" autocomplete="off" style="display:none"> <!-- honeypot -->
  <button>Avisar que presenteei 💌</button>
</form>
```

```js
avisoForm.addEventListener("submit", async e => {
  e.preventDefault();
  avisoForm.presente.value = presenteAtual.nome;
  const r = await fetch(avisoForm.action, { method: "POST", body: new FormData(avisoForm),
                                            headers: { Accept: "application/json" } });
  if (r.ok) { marcarComoEscolhido(presenteAtual.id); pixModal.close(); }
});
```

Persistência visual local:

```js
const KEY = "cha_escolhidos";
const escolhidos = new Set(JSON.parse(localStorage.getItem(KEY) || "[]"));
function marcarComoEscolhido(id) { escolhidos.add(id); localStorage.setItem(KEY, JSON.stringify([...escolhidos])); }
```

### E) Flores mais leves

```js
const reduz = matchMedia("(prefers-reduced-motion: reduce)").matches;
let timer;
function iniciarFlores() { if (!reduz && !timer) timer = setInterval(createFlower, 900); }
function pararFlores()   { clearInterval(timer); timer = null; }
document.addEventListener("visibilitychange", () => document.hidden ? pararFlores() : iniciarFlores());
iniciarFlores();
```

```html
<meta name="description" content="Lista de presentes do Chá de Panela de Nathalia e Raphael.">
<meta property="og:title" content="Chá de Panela – Nathalia e Raphael">
<meta property="og:description" content="Crônicas da Alta Sociedade: escolha um mimo para o novo lar.">
<meta property="og:image" content="https://SEU-DOMINIO/og.jpg">
<meta name="theme-color" content="#c9a24b">
<meta name="robots" content="noindex">
```

---

## 12\. Plano de execução sugerido

1. (1-2 h) Pix válido + QR local + constantes + copia-e-cola correto → testar com pagamento de R$ 0,01.

2. (1 h) Modal em `<dialog>`, semântica "Já paguei" opcional, `localStorage`.

3. (2-3 h, depende de conseguir as fotos) Imagens otimizadas + lazy + alt + fallback.

4. (30 min) Meta/OG/noindex, flores otimizadas.

5. (opcional, 30 min) Formspree/Google Sheets.

_Limitações:_ análise estática do código; não foi possível verificar a imagem `w1-removebg-preview.png` (arquivo não fornecido), nem testar o site em dispositivos reais, nem confirmar se `00636779203` é de fato um CPF (inferência pelo formato de 11 dígitos). Estimativas de tempo são aproximadas.