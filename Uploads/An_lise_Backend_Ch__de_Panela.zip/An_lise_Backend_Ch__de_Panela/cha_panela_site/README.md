# Chá de Panela — Nathalia e Raphael (tema Bridgerton)

Site **100% estático** (sem backend e sem banco de dados) para a lista de presentes do chá de panela.
É só abrir o `index.html` em qualquer navegador ou hospedar a pasta inteira em qualquer serviço de arquivos estáticos (GitHub Pages, Netlify, Vercel, etc.).

## Conteúdo da pasta

```
cha_panela_site/
├── index.html      → estrutura e estilo (visual Bridgerton preservado)
├── app.js          → configuração, dados dos presentes e toda a lógica
├── qrcode.js       → gerador de QR Code local (biblioteca MIT, roda offline)
├── images/         → fotos dos presentes (.webp + fallback .jpg, ~600px)
└── README.md       → este arquivo
```

## Como editar (tudo fica no topo do `app.js`)

No objeto **`CONFIG`** você ajusta:

| Campo | O que é |
|-------|---------|
| `pixKey` | Chave Pix aleatória (EVP) do casal — já preenchida. |
| `recebedor` | Nome exibido pelo banco. **Máx. 25 caracteres, sem acentos.** |
| `cidade` | **PLACEHOLDER:** está como `"CIDADE"`. Troque pela cidade real do casal antes de publicar (máx. 15 caracteres, sem acentos). |
| `txid` | Identificador da transação. `"***"` = QR estático padrão. |
| `cartaoLinkBase` | **Pagamento com cartão — ainda NÃO implementado.** Campo deixado vazio de propósito (placeholder documentado). Será preenchido numa etapa futura. |
| `avisoFormUrl` | Opcional: URL de um formulário (ex.: Formspree) para o casal saber quem presenteou. **Enquanto vazio, o recurso fica desativado** e nenhuma requisição é feita. |

A lista de presentes fica no array **`PRESENTES`** (nome, valor numérico, imagem, texto alternativo e emoji de fallback), separada da lógica.

## O que foi corrigido (conforme o relatório de análise)

- **Pix válido:** o QR agora é um **BR Code EMV real com CRC16** gerado no navegador, já com o valor do presente. Antes era um texto solto que o banco rejeitava.
- **Sem APIs de terceiros:** o QR Code é desenhado **localmente** (`qrcode.js`). Nada é enviado para `qrserver.com` nem para qualquer outro serviço.
- **Dados sensíveis removidos:** o CPF que estava no HTML foi retirado. Usa-se a chave aleatória (EVP).
- **"Copia e cola" correto:** o botão copia o código Pix completo (com valor), com fallback para navegadores sem `clipboard`.
- **Reserva honesta:** fechar o modal **não** marca mais o item como "escolhido". Como o casal aceita presentes repetidos, nenhum item é bloqueado. Existe um botão explícito **"Já fiz o Pix"** que registra apenas no `localStorage` **do próprio visitante** (ninguém mais vê).
- **Modal acessível:** usa `<dialog>` nativo — fecha com **ESC**, tem foco preso, `aria-modal`, retorno de foco ao botão de origem, trava o scroll do fundo, fecha ao clicar no fundo e é responsivo.
- **Imagens reais:** cada presente com foto usa `<picture>` WebP + fallback JPG, com `loading="lazy"`, `alt` descritivo, `width/height` e fallback por emoji em caso de erro.
- **Performance/qualidade:** flores animadas com pausa em aba oculta e respeito a `prefers-reduced-motion`; textos inseridos com `textContent` (sem risco de XSS); meta tags de SEO/Open Graph/viewport; HTML semântico (`header`/`main`/`h1`/`ul`); foco visível e `noindex` (o site tem chave Pix e nomes).

## Mapeamento presente → imagem

| Presente | Imagem |
|----------|--------|
| Jogo de Panelas de Cerâmica | `images/panelas` |
| Formas e Assadeiras | `images/assadeiras` |
| Frigideira Antiaderente | `images/frigideira` |
| Faqueiro | `images/faqueiro` |
| Conjunto de Pratos | `images/pratos` |
| Conjunto de Copos | `images/copos` |
| Conjunto de Taças | `images/tacas` |
| Conjunto de Xícaras | `images/xicaras` |
| Jogo de Banho | `images/jogo_banho` |
| Kit de Toalhas | `images/toalhas` |
| Edredom Casal | `images/edredom` |
| Liquidificador | `images/liquidificador` |
| Air Fryer | `images/airfryer` |
| Cafeteira | `images/cafeteira` |
| Sanduicheira | `images/sanduicheira` |
| Almofadas | `images/almofadas` |
| Utensílios de Cozinha | `images/utensilios` |
| Tábua de Corte | `images/tabua` |
| Escorredor de Louça | `images/escorredor` |
| Potes Organizadores | `images/potes` |
| Kit de Temperos | `images/temperos` |

## Limitações e observações

- **2 presentes ficaram sem foto** (fallback elegante com emoji temático): **Jogo de Panelas de Cerâmica** e **Escorredor de Louça** — não havia imagem correspondente entre as enviadas. Basta adicionar `panelas.webp/.jpg` e `escorredor.webp/.jpg` em `images/` e trocar `img: null` por `img: "panelas"` / `img: "escorredor"` no `app.js`.
- **Kit de Toalhas agora com foto:** a imagem `toalhas.jpg` enviada pelo usuário foi convertida (600×600, WebP + JPG) e associada ao item "Kit de Toalhas".
- **Nenhuma foto enviada ficou sem uso** — todas as 19 imagens estão associadas a um presente.
- **Cidade do Pix:** está como `"CIDADE"` (placeholder). Ajuste em `CONFIG.cidade` antes de publicar.
- **Pagamento com cartão:** propositalmente **não implementado** nesta etapa (apenas o campo `cartaoLinkBase` como placeholder documentado).
- Antes de divulgar, recomenda-se um **pagamento real de teste (R$ 0,01)** lendo o QR em um app de banco para conferência final.

## Testes realizados (navegador headless)

- 21 cards renderizados; **19 fotos carregam sem erro**, 2 em fallback; **nenhuma imagem quebrada e nenhum 404**.
- Modal abre ao clicar em "Presentear" e **fecha com ESC**.
- O payload Pix gerado passa na **validação de CRC16** (recalculado e conferido; algoritmo também validado contra um BR Code de referência).
- QR Code gerado localmente (data URI, sem rede).
- **Sem erros no console.**
