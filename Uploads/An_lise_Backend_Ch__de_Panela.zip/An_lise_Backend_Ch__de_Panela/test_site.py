import os, re
os.environ["PLAYWRIGHT_BROWSERS_PATH"] = "/home/ubuntu/.pw-browsers"
from playwright.sync_api import sync_playwright

BASE = "http://localhost:8777/"
console_msgs, failed_reqs = [], []

def crc16(s):
    crc = 0xFFFF
    for b in s.encode():
        crc ^= b << 8
        for _ in range(8):
            crc = ((crc << 1) ^ 0x1021) & 0xFFFF if crc & 0x8000 else (crc << 1) & 0xFFFF
    return format(crc, "04X")

with sync_playwright() as p:
    br = p.chromium.launch()
    pg = br.new_page()
    pg.on("console", lambda m: console_msgs.append((m.type, m.text)))
    pg.on("requestfailed", lambda r: failed_reqs.append((r.url, r.failure)))
    pg.on("response", lambda r: failed_reqs.append((r.url, f"HTTP {r.status}")) if r.status >= 400 else None)

    pg.goto(BASE, wait_until="networkidle")

    # Força carregamento das imagens lazy rolando a pagina
    pg.evaluate("window.scrollTo(0, document.body.scrollHeight)")
    pg.wait_for_timeout(1500)

    cards = pg.query_selector_all("#gifts .card")
    print("Cards renderizados:", len(cards))

    # Verifica imagens carregadas (naturalWidth > 0) vs fallback
    img_info = pg.evaluate("""() => {
        const out = [];
        document.querySelectorAll('#gifts .card').forEach(c => {
            const id = c.dataset.id;
            const img = c.querySelector('img');
            const icon = c.querySelector('.card-icon');
            out.push({id, hasImg: !!img, loaded: img ? (img.complete && img.naturalWidth>0) : false, fallback: !!icon, src: img ? img.currentSrc||img.src : null});
        });
        return out;
    }""")
    broken = [i for i in img_info if i["hasImg"] and not i["loaded"]]
    fallbacks = [i["id"] for i in img_info if i["fallback"]]
    print("Imagens com foto que carregaram OK:", sum(1 for i in img_info if i["hasImg"] and i["loaded"]))
    print("Fallback (sem foto):", fallbacks)
    print("Imagens QUEBRADAS:", [i["id"] for i in broken])

    # Abre o modal do primeiro card
    cards[0].query_selector("button.reserve").click()
    pg.wait_for_timeout(400)
    is_open = pg.evaluate("document.getElementById('pixModal').open")
    print("Modal aberto:", is_open)

    # Pega o payload Pix e valida CRC
    payload = pg.inner_text("#pixCopiaCola")
    print("Payload (card 1):", payload)
    body, crc_in = payload[:-4], payload[-4:]
    print("CRC16 recalculado:", crc16(body), "| embutido:", crc_in, "| VALIDO?", crc16(body) == crc_in)
    # QR presente?
    qr_img = pg.query_selector("#qrcode img")
    print("QR Code gerado localmente (data URI):", bool(qr_img) and qr_img.get_attribute("src").startswith("data:"))

    # Fecha com ESC
    pg.keyboard.press("Escape")
    pg.wait_for_timeout(300)
    print("Modal fechado com ESC:", not pg.evaluate("document.getElementById('pixModal').open"))

    br.close()

print("\n--- Requisicoes com falha/404 ---")
real_fail = [f for f in failed_reqs if "favicon" not in f[0]]
for u in real_fail: print(u)
if not real_fail: print("(nenhuma)")

print("\n--- Console ---")
errs = [m for m in console_msgs if m[0] in ("error",)]
for m in console_msgs: print(m)
if not errs: print(">> Sem erros de console")
